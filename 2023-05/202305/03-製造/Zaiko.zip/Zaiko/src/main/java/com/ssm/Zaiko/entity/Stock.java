package com.ssm.Zaiko.entity;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class Stock implements Serializable{
	
		
		//在庫ID
		private String stockId;
		
		//在庫商品名称
		private String name;
		
		//単位ID
		private String unitId;
		
		//在庫数量
		private int stockNum;
		
		//備考
		private String remarks;
		
		//削除フラグ
	    private int delFlg;
	    
	    //作成日時
	    private Date createDate;
	    
	    //作成者
	    private int createUser;
		
		//更新日時
		private Date updateDate;

		//更新者i
		private int updateUser;

		private boolean checked;
		
		private String unitName;
		
		private int rowId;
		
		
		
		
		

}
