package com.ssm.Zaiko.entity;

import java.io.Serializable;

import lombok.Data;

@Data
public class MCode implements Serializable{
	
	private String codeKbn;
	
	private String codeId;
	
	private String codeName;
	
	private int delFlg;
	
	
}