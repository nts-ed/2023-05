package com.ssm.Zaiko.form;

import java.io.Serializable;

import lombok.Data;
@Data
public class AddForm implements Serializable{
	private String stockId;
	private String name;
	private String unitId;
	private String remarks;

}
