package com.ssm.Zaiko.form;

import lombok.Data;

@Data
public class MCodeForm {
	 private String codeId;
	 private String codeName;

}
