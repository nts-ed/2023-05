package com.ssm.Zaiko.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ssm.Zaiko.entity.MCode;
import com.ssm.Zaiko.entity.Stock;
import com.ssm.Zaiko.form.AddForm;
import com.ssm.Zaiko.form.SearchForm;
import com.ssm.Zaiko.service.MCodeService;
import com.ssm.Zaiko.service.StockService;

@Controller
public class ListController {
	@Autowired
	private MCodeService mCodeService;
	@Autowired
	private StockService stockService;

	//private List<MCode> departmentList ;

	//在庫情報一覧画面
	@GetMapping(value = "/zaiko/view")
	public String homeView(Model model) {
		List<Stock> stoList = stockService.findAll();

		model.addAttribute("stockList", stoList);
		model.addAttribute("searchForm", new SearchForm());
		return "zaiko/zaikolist";
	}

	//検索処理
	@PostMapping(value = "/zaiko/search")
	public String searchView(Model model, SearchForm searchForm) {
		List<Stock> stoList = stockService.findByCondition(searchForm);
		model.addAttribute("stockList", stoList);
		List<MCode> mcodeList = mCodeService.iFindUnitName();
		model.addAttribute("mcodeList", mcodeList);

		return "zaiko/zaikolist";
	}

	//削除
	@PostMapping(value = "/zaiko/delete")
	public String deleteView(@RequestParam("selectedStock") List<Integer> selectedStock) {
		for (int selectId : selectedStock) {
			stockService.deleteStock(selectId);
		}

		return "redirect:/zaiko/view";
	}

	//ログアウト用
	@GetMapping("/zaiko/logout")
	public String logout(Model model) {

		return "/zaiko/login";
	}

	//
	@GetMapping("/zaiko/input")
	public String input(Model model) {

		return "/zaiko/inputlist";
	}

	@GetMapping("/zaiko/update")
	public String update(Model model) {
		AddForm addForm = new AddForm();
		Stock stock = stockService.findMaxIndexOfStock();
		Number stockNumber = Number.class.cast(Integer.parseInt(stock.getStockId().substring(2)) + 1);
		String stockIdString = "000000000" + stockNumber.toString();
		String stockId = stockIdString.substring(stockIdString.length() - 9);
		addForm.setStockId("No" + stockId);

		model.addAttribute("addForm", addForm);

		return "/zaiko/update";
	}

	@GetMapping("/zaiko/add")
	public String add(Model model) {
		AddForm addForm = new AddForm();
		Stock stock = stockService.findMaxIndexOfStock();
		Number stockNumber = Number.class.cast(Integer.parseInt(stock.getStockId().substring(2)) + 1);
		String stockIdString = "000000000" + stockNumber.toString();
		String stockId = stockIdString.substring(stockIdString.length() - 9);
		addForm.setStockId("No" + stockId);

		model.addAttribute("addForm", addForm);
		return "/zaiko/update";
	}

}
