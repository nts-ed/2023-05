package com.ssm.Zaiko;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@MapperScan("com.ssm.Zaiko")
@SpringBootApplication
public class ZaikoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZaikoApplication.class, args);
	}

}
