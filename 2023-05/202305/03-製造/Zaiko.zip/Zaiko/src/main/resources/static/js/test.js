/**
 * 
 */

 document.addEventListener('DOMContentLoaded', function() {
  var testMessage = document.createElement('p');
  testMessage.textContent = 'This is a test message from JavaScript.';
  document.body.appendChild(testMessage);
});
