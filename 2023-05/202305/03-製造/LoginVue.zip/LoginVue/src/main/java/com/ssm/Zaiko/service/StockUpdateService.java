package com.ssm.Zaiko.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.ssm.Zaiko.dao.StockUpdateMapper;
import com.ssm.Zaiko.entity.Stock;
import com.ssm.Zaiko.form.AddForm;
import com.ssm.Zaiko.form.UpdateForm;
@Component
@Service
public class StockUpdateService { 
	public StockUpdateService() {System.out.println("check"+getClass().getSimpleName());
		
	}
	@Autowired
	private StockUpdateMapper stockUpdateMapper;

	public void add(AddForm form) {
		// 将新的库存信息添加到数据库
		stockUpdateMapper.add(form);
	}

	public void update(UpdateForm form) {
		// 更新库存信息
		stockUpdateMapper.update(form);
	}

	public Stock findMaxIndexOfStock() {
		return stockUpdateMapper.findMaxIndexOfStock();
	}
	
	
	}
		


