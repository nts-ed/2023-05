package com.ssm.Login;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@MapperScan("com.ssm.Zaiko")
@SpringBootApplication(
		scanBasePackages = {"com.ssm.Login",
							"com.ssm.test",
				            "com.ssm.Zaiko"}
)
public class LoginVueApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginVueApplication.class, args);
	}

}
