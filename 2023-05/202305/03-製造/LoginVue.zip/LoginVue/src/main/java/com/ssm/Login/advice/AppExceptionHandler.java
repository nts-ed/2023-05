package com.ssm.Login.advice;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.ssm.Login.exception.BusinessException;

/*
 * Global Exception Handler
 * 開発debug用
 * author:馬 広超(Rothschilds MA)
 * 作成:2023/05/06
*/

@RestControllerAdvice
public class AppExceptionHandler {
	
	//メソッド引数が無効な場合にスローされる例外
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String,String>> handleInvalidArgument(MethodArgumentNotValidException ex){
		Map<String, String> errorMap = new HashMap<>();
		ex.getBindingResult().getFieldErrors().forEach(error -> {
			errorMap.put(error.getField(), error.getDefaultMessage());
		});
		
		return ResponseEntity.badRequest().body(errorMap);
	}
	
	//業務例外
	@ExceptionHandler(BusinessException.class)
	public ResponseEntity<Map<String,String>> handleBusinessException(BusinessException ex){
		Map<String, String> errorMap = new HashMap<>();
		
		errorMap.put("errorMessage", ex.getMessage());
		
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorMap);
	}
	

}
