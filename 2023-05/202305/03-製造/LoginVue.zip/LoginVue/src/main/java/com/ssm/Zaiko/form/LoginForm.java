package com.ssm.Zaiko.form;

import lombok.Data;

@Data
public class LoginForm {
	//社員ID
		private String userId;
		public String getUserId() {
	        return userId;
	    }
		
		//パスワード
		private String password;
		

	}


