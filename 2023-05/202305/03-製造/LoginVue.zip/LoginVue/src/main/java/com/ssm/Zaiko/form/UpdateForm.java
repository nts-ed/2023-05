package com.ssm.Zaiko.form;

import java.io.Serializable;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class UpdateForm implements Serializable{
    // ID
	private int Id;

	// 在庫商品ID
	private String stockId;
	// 在庫商品名
	@NotBlank(message = "商品名を入力してください")
	@Size(max = 20, message = "20文字以内で入力してください。")
	private String name;

	// 単位ID
	@NotBlank(message = "単位を選択してください。")
	private String unitId;
	
	// 在庫数量
	private String stockNum;
	// 備考
	@Size(max = 200, message = "200文字以内で入力してください。")
	private String remarks;
		
	// 作成月日
	private String createUser;
	// 作成者
	private String creatDate;

	// 更新月日
	private String updateDate;
	// 更新者
	private String updateUser;

}
