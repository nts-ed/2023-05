package com.ssm.Login.config;

import java.io.IOException;

import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.ssm.Login.repository.TokenRepository;
import com.ssm.Login.service.TokenService;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

/*
 * JSON WEB TOKEN 認証フィルター
 * Header check using Authorization: Bearer
 * author:馬 広超(Rothschilds MA)
 * 作成:2023/05/06
 */

@Component
@RequiredArgsConstructor
public class AuthenticationFilter extends OncePerRequestFilter{

	private final UserDetailsService userDetailsService;
	private final TokenRepository tokenRepository;
	private final TokenService tokenService;
	
	/*
	 * フィルターロジック
	 * リクエストごとに呼び出し
	 * OncePerRequestFilter
	 */
	@Override
	protected void doFilterInternal(
			@NonNull HttpServletRequest request,
			@NonNull HttpServletResponse response,
			@NonNull FilterChain filterChain)throws ServletException, IOException {
		
		//Authorization: Bearer <token>
		final String authHeader = request.getHeader("Authorization");
		
		if(authHeader == null || !authHeader.startsWith("Bearer ")) {
			filterChain.doFilter(request, response);
			return;
		}
		
		final String jwt = authHeader.substring(7);
		

		final String userId = tokenService.getTokenSubject(jwt);
		
		//userIdがnullではない && 現在のリクエストがまだ認証されていない
		if(userId != null && SecurityContextHolder.getContext().getAuthentication() == null) {
			
			UserDetails userDetails = this.userDetailsService.loadUserByUsername(userId);
			
			var token = tokenRepository.findByToken(jwt).orElse(null);
			
			boolean isTokenValid = token != null && (token.getExpired() == 0 && token.getRevoked() == 0);

			if(tokenService.isTokenValid(jwt, userDetails) && isTokenValid) {
				
				//認証トークンのオブジェクト生成、認証に成功したユーザーの情報を保持する
				UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(userDetails, null,userDetails.getAuthorities());
				
				//認証トークンの詳細情報を設定
				authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				
				//認証情報をセキュリティコンテキストに設定
				SecurityContextHolder.getContext().setAuthentication(authToken);
				
			}
		}
		filterChain.doFilter(request, response);
	}

}
