package com.ssm.Login.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.authentication.logout.LogoutHandler;

import lombok.RequiredArgsConstructor;

/*
 * Security設定クラス
 * FrameWork:Spring Security
 * author:馬 広超(Rothschilds MA)
 * 作成:2023/05/04
*/

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

	//認証フィルター
	private final AuthenticationFilter authFilter;

	//認証プロバイダ
	private final AuthenticationProvider authenticationProvider;

	//ログアウトハンドラ
	private final LogoutHandler logoutHandler;

	@Bean
	SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

		http.csrf().disable()
				.authorizeHttpRequests(authorize -> authorize
						.requestMatchers("/css/**").permitAll()
						.requestMatchers("/*.js").permitAll()
						.requestMatchers("/api/auth/**").permitAll()
//						.requestMatchers(PathRequest.toStaticResources().atCommonLocations()).permitAll()					
						.anyRequest().authenticated())
				.formLogin(form -> {
					form
					.loginPage("/api/auth/login")
					.permitAll();
				})
				.sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS)
				.and()
				.authenticationProvider(authenticationProvider)
				.addFilterBefore(authFilter, UsernamePasswordAuthenticationFilter.class)
				.logout()
				.logoutUrl("/api/v1/auth/logout")
				.addLogoutHandler(logoutHandler)
				.logoutSuccessHandler((request, response, authentication) -> SecurityContextHolder.clearContext());

		return http.build();
	}

}
