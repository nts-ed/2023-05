package com.ssm.Login.controller;

import java.io.IOException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ssm.Login.dto.request.AddUserRequest;
import com.ssm.Login.dto.request.LoginRequest;
import com.ssm.Login.dto.response.LoginResponse;
import com.ssm.Login.service.LoginService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

/*
 * Loginコントローラークラス
 * author:馬 広超(Rothschilds MA)
 * 作成:2023/05/05
*/

@RestController
@CrossOrigin
@RequestMapping(value = "/api/v1/auth")
@RequiredArgsConstructor
public class LoginController {
	
	private final LoginService loginService;
	

	@GetMapping(value = "/hello")
	public String hello() {
		return "hello";
	}
	
	@PostMapping("/add")
	public ResponseEntity<LoginResponse> add(@RequestBody AddUserRequest addRequest){
		
		return ResponseEntity.ok(loginService.add(addRequest));
		
	}
	
	@PostMapping("/authenticate")
	public ResponseEntity<LoginResponse> authenticate(@RequestBody LoginRequest loginRequest){
		
		return ResponseEntity.ok(loginService.authenticate(loginRequest));
		
	}
	
	@PostMapping("/refreshToken")
	public void refreshToken(HttpServletRequest request,HttpServletResponse response) throws IOException{
		
		loginService.refreshToken(request,response);
	}
	
	
	/*@PostMapping(value = "/add")
	public String add(@RequestBody @Valid AddUserRequest addRequest) {
		loginService.add(addRequest);
		
		return "add";
	}
	
	@PostMapping(value = "/login")
	public LoginResponse login(@RequestBody @Valid LoginRequest loginRequest,HttpServletResponse response) throws Exception{
		
		Login login = loginService.login(loginRequest);
		
		Cookie cookie = new Cookie("refresh_token", login.getrefreshToken());
		cookie.setMaxAge(3600);
		cookie.setHttpOnly(true);
		cookie.setPath("/api");
		
		response.addCookie(cookie);
	
		return new LoginResponse(login.getAccessToken());
	}
	
	
	@GetMapping(value = "/user")
	public UserResponse user(HttpServletRequest request) {
		var user = (User) request.getAttribute("user");
		return new UserResponse(user);
	}*/

	
}
