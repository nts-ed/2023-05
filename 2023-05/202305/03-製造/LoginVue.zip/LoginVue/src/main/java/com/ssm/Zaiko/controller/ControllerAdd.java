package com.ssm.Zaiko.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ssm.Zaiko.entity.Stock;
import com.ssm.Zaiko.form.AddForm;
import com.ssm.Zaiko.service.StockUpdateService;
@Controller
@RequestMapping(value = "/api/auth")
public class ControllerAdd {
	
	@Autowired
	  private StockUpdateService stockUpdateService;
	    private AddForm addForm;
//	    private StockService stockService; // 添加这行声明

	  



		@GetMapping("/stock/add")
		public String add(Model model) {
			AddForm addForm = new AddForm();
			Stock stock =stockUpdateService.findMaxIndexOfStock();
			Number stockNumber = Number.class.cast(Integer.parseInt(stock.getStockId().substring(2)) + 1);
			String stockIdString = "000000000" + stockNumber.toString();
			String stockId = stockIdString.substring(stockIdString.length() - 9);
			addForm.setStockId("No" + stockId);

			model.addAttribute("addForm", addForm);
			return "/stockUpdate/add";
		}

		 
	    //在庫情報登録
	    @RequestMapping(value = "/stock/insert", method = RequestMethod.POST)
	    public String addToTable(@Validated AddForm addForm, BindingResult result, Model model) {
	        if (result.hasErrors()) {
	            //UpdateForm updateForm = new UpdateForm();
	           // model.addAttribute("updateForm", updateForm);
	            return "/stock/add";
	        }
	        stockUpdateService.add(addForm);
	        return "redirect:/api/auth/zaiko/view";
	        
	    }     
       
}