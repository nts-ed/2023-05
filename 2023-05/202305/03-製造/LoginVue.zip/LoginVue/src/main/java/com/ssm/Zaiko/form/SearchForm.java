package com.ssm.Zaiko.form;

import java.io.Serializable;

import lombok.Data;

@Data
public class SearchForm implements Serializable{
	//在庫商品名称
	private String name;
			
	//単位ID
	private String unitId;
	
	
	private String startDate;
	
	
	private String endDate;
	
	

}
