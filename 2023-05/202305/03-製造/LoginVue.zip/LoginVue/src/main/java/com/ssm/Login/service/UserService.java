package com.ssm.Login.service;

import java.util.List;
import java.util.function.Supplier;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.ssm.Login.builder.TemplateBuilder;
import com.ssm.Login.dto.request.AddUserRequest;
import com.ssm.Login.entity.Token;
import com.ssm.Login.entity.User;
import com.ssm.Login.enumeration.AuthorityType;
import com.ssm.Login.enumeration.TokenType;
import com.ssm.Login.repository.TokenRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {
	
	private final TokenRepository tokenRepository;
	private final PasswordEncoder passwordEncoder;
	
	public User buildUser(AddUserRequest addRequest) {
		
		//パスワード暗号化->BCrypt
		String hashedpassword = passwordEncoder.encode(addRequest.getPassword());
		
		TemplateBuilder<User> userBuilder = TemplateBuilder.of(User::new);
		
		User user = userBuilder
						.field("userId", addRequest.getUserId())
						.field("userName", addRequest.getUserName())
						.field("password", hashedpassword)
						.field("authority",AuthorityType.USER)
						.build();
		
		return user;
	}
	
	public void saveUserToken(User user,String jwtToken) {
		
		Supplier<Token> tokensSupplier = () -> new Token();
		
		Token token = TemplateBuilder.of(tokensSupplier)
						.field("user", user)
						.field("token", jwtToken)
						.field("tokenType", TokenType.BEARER)
						.field("expired", 0)
						.field("revoked", 0)
						.build();
		
		tokenRepository.save(token);
		
	}
	
	
	public void revokeAllUserTokens(User user) {
		
		List<Token> userTokens = tokenRepository.findAllTokensByUser(user.getId());
		
		if(userTokens.isEmpty()) return;
		userTokens.forEach(token -> { token.setExpired(1); token.setRevoked(1);});
		
		tokenRepository.saveAll(userTokens);
		
	}

}
