package com.ssm.Login.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/api")
public class DemoCon {
	
	@GetMapping(value = "/demo")
	public String demo() {
		
		return "login/hello";
	}
}
