package com.ssm.Zaiko.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssm.Zaiko.entity.Stock;
import com.ssm.Zaiko.form.SearchForm;


@Mapper
public interface StockMapper {
	
    List<Stock> findAll();

    List<Stock> findByCondition(SearchForm form);
    
    Stock findMaxIndexOfStock();
    
    void deleteStock(int rowId);
    
    int getRowid();
    
    Stock findByid(String stockId);
}