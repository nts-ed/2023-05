package com.ssm.Login.service;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.ssm.Login.builder.TokenFactory;
import com.ssm.Login.enumeration.TokenType;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;


@Service
public class TokenService {
	
	@Value("${application.security.token-secret}")
	private String tokenSecret;
	
	@Value("${application.security.access-token.expiration}")
	private long accessTokenExpiration;
	
	@Value("${application.security.refresh-token.expiration}")
	private long refreshTokenExpiration;
	
	
	
	public String createToken(UserDetails userDetails,TokenType tokenType) {
		long expiration = 0;
		switch (tokenType) {
			case ACCESS:
				expiration = accessTokenExpiration;
				break;
			
			case REFRESH:
				expiration = refreshTokenExpiration;
				break;
			
			default:
				break;
		}

		return TokenFactory.of(new HashMap<>(), userDetails, expiration, getTokenSecretKey(tokenSecret)).getToken();
	}
	
	public boolean isTokenValid(String token, UserDetails userDetails) {
		final String username = getTokenSubject(token);
		return (username.equals(userDetails.getUsername())) && !isTokenExpired(token);
	}

	

	/*
	 * JWT_PAYLOAD DATA
	 * すべてクレーム抽出処理
	 * 
	 * Registered Claims（登録済みクレーム）
	 * 
	 * iss（Issuer）		 : 発行したエンティティ（発行者）の識別子
	 * sub（Subject）		 : 関連付けられている主体（ユーザーなど）の識別子
	 * aud（Audience）		 : 受信者（APIなど）の識別子
	 * exp（Expiration Time）: 有効期限
	 * iat（Issued At）		 : 発行時刻
	 * nbf（Not Before）	 : 利用可能開始時刻
	*/
	private Claims getAllClaims(String token) {
		
		//解析器ビルド処理
		JwtParser jwtParser = Jwts.parserBuilder()
									.setSigningKey(getTokenSecretKey(tokenSecret))
									.build();
		
		//token解析、claim抽出処理  JWS(JSON Web Signature)
		Claims claims = jwtParser.parseClaimsJws(token).getBody();
		
		return claims;
	}
	
	//秘密鍵デコード&取得処理、keyオブジェクト生成
	private Key getTokenSecretKey(String secretKey) {
		byte[] keyBytes = Decoders.BASE64.decode(secretKey);
		return Keys.hmacShaKeyFor(keyBytes);
	}

	//特定のクレーム抽出
	private <T>T getClaim(String token,Function<Claims,T> claimsResolver){
		final Claims claims = getAllClaims(token);
		return claimsResolver.apply(claims);
	}
	
	public String getTokenSubject(String token) {
		return getClaim(token, Claims::getSubject); 
	}

	private Date getTokenExpiration(String token) {
		Date expiration = getClaim(token, Claims::getExpiration);
		return expiration;
	}

	private boolean isTokenExpired(String token) {
		return getTokenExpiration(token).before(new Date());
	}


}
