package com.ssm.Zaiko.entity;

import java.io.Serializable;
import java.util.Date;

import jakarta.persistence.Table;
import lombok.Data;
@Data
@Table(name = "t_user")
public class User implements Serializable {

	
		//社員ID
		private String userId;
		
		//パスワード
		private String password;
		
		//削除フラグ
	    private int delFlg;

		//作成日時
		private Date createDate;

		//作成者id
		private String createUser;

		//更新日時
		private Date updateDate;

		//更新者id
		private String updateUser;

		
		

	}

