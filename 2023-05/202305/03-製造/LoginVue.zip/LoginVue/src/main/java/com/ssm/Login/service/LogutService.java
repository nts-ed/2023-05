package com.ssm.Login.service;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.stereotype.Service;

import com.ssm.Login.entity.Token;
import com.ssm.Login.repository.TokenRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class LogutService implements LogoutHandler{
	
	private final TokenRepository tokenRepository;

	@Override
	public void logout(
			HttpServletRequest request, 
			HttpServletResponse response, 
			Authentication authentication) {
		
		//Authorization: Bearer <token>
		final String authHeader = request.getHeader("Authorization");
				
		if(authHeader == null || !authHeader.startsWith("Bearer ")) return;
				
		final String jwt = authHeader.substring(7);
		
		Token token = tokenRepository.findByToken(jwt).orElse(null);
		if(token != null) {
			token.setExpired(1);
			token.setRevoked(1);
			tokenRepository.save(token);
		}
		
	}

}
