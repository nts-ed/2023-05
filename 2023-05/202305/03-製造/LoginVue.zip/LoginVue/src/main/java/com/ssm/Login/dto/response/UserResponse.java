package com.ssm.Login.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.ssm.Login.entity.User;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class UserResponse {
	
	private Long id;
	
	@JsonProperty("user_id")
	private String userId;
	
	@JsonProperty("user_name")
	private String userName;
	
	private String password;
	
	private User user;
	
	public UserResponse(User user) {
		this.user = user;
	}

}
