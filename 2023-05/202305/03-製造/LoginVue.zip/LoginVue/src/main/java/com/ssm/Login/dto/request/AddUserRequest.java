package com.ssm.Login.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/*
 * DTO:ユーザー追加リクエストデータ
 * author:馬 広超(Rothschilds MA)
 * 作成:2023/05/04
*/

@Getter
@Setter
@ToString
public class AddUserRequest implements Serializable{

	@JsonProperty("user_id")
	private String userId;
	
	@JsonProperty("user_name")
	private String userName;
	
	private String password;
	

	
}
