package com.ssm.Login.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssm.Login.dto.request.LoginRequest;
import com.ssm.Login.service.LoginService;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping(value = "/api/v1/auth")
@RequiredArgsConstructor
public class LogindfuController {
	
	private final LoginService loginService;
	
	@GetMapping(value = "login")
	public String login(LoginRequest loginRequest) {
		return "login";
	}
	
	
	@PostMapping("/authenticate")
	public String authenticate(LoginRequest loginRequest){
		
		loginService.authenticate(loginRequest);
		
		return "redirect:/api/v1/auth/hello";
		
	}
	
	@GetMapping(value = "hello")
	public String login2() {
		return "hello";
	}
	

}
