package com.ssm.Login.controller;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ssm.Login.dto.request.LoginRequest;
import com.ssm.Login.dto.response.LoginResponse;
import com.ssm.Login.entity.User;
import com.ssm.Login.repository.UserRepository;
import com.ssm.Login.service.LoginService;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping(value = "/api/auth")
@RequiredArgsConstructor
public class LogindfuController {

	private final LoginService loginService;
	private final UserRepository userRepository;
	private final PasswordEncoder passwordEncoder;

	@GetMapping(value = "login")
	public String login(LoginRequest loginRequest) {
		return "login/login";
	}

	@RequestMapping(value = "/authenticate",method = RequestMethod.POST)
	public String authenticate(
			@Validated LoginRequest loginRequest, 
			BindingResult result,
			Model model,
			HttpServletResponse response) {
		
		
		
		
		if(result.hasErrors()) {
			return "login/login";
		}else {
			User user = userRepository.findByUserId(loginRequest.getUserId()).orElse(null);
			
			if(user == null) {
				model.addAttribute("msg","IDが間違っています。");
				return "login/login";
			}
			if(passwordEncoder.matches(loginRequest.getPassword(), user.getPassword()) == false) {
				model.addAttribute("msg","パスワードが間違っています。");
				return "login/login";
			}
			
			LoginResponse loginResponse = loginService.authenticate(loginRequest);
			Cookie cookie = new Cookie("access_token",loginResponse.getAccessToken());
			cookie.setMaxAge(86400);
			cookie.setHttpOnly(true);
			cookie.setPath("/api");
			
			
			response.addCookie(cookie);
			
			String token = loginResponse.getAccessToken();
			String authorizationHeader = "Bearer " + token;

			response.setHeader("Authorization", authorizationHeader);
			
			
		}



		return "redirect:/api/auth/zaiko/view";

	}
	


	@GetMapping(value = "hello")
	public String testhe() {
		return "login/hello";
	}

}
