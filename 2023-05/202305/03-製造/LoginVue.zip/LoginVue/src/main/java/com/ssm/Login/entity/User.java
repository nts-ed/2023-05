package com.ssm.Login.entity;

import java.util.Collection;
import java.util.List;

import org.springframework.core.annotation.Order;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.ssm.Login.enumeration.AuthorityType;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*
 * ユーザーアカウント
 * author:馬 広超(Rothschilds MA)
 * 作成:2023/05/04
*/

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="t_user")
@Order(1)
public class User implements UserDetails{

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "id")
	private Long id;
	

	@Column(name = "user_id",length = 11)
	private String userId;
	
	@Column(name = "user_name",length = 50)
	private String userName;
	
	
	@Column(name = "password",length = 64)
	private String password;
	
	@Column(name = "del_flg")
	private int delFlg; 
	
	@Column(name = "create_date",length = 11)
	private String createDate;
	
	@Column(name = "create_user",length = 11)
	private String createUser;
	
	@Column(name = "update_date",length = 11)
	private String upateDate;
	
	@Column(name = "update_user",length = 11)
	private String upateUser;

	@Column(name = "authority")
	@Enumerated(EnumType.STRING)
	private AuthorityType authority;
	
	@OneToMany(mappedBy = "user")
	private List<Token> tokens;
	
	public String getName() {
		return this.userName;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return List.of(new SimpleGrantedAuthority(authority.name()));
	}

	@Override
	public String getUsername() {
		return this.userId;
	}
	

	@Override
	public String getPassword() {
		return this.password;
	}
	

	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Override
	public boolean isEnabled() {
		return true;
	}

	
}
