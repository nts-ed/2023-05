package com.ssm.Login.enumeration;

public enum TokenType {
	
	BEARER,
	
	ACCESS,
	REFRESH

}
