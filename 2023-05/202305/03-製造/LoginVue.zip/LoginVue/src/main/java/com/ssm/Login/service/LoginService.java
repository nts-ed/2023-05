package com.ssm.Login.service;


import java.io.IOException;
import java.util.function.Supplier;

import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ssm.Login.builder.TemplateBuilder;
import com.ssm.Login.dto.request.AddUserRequest;
import com.ssm.Login.dto.request.LoginRequest;
import com.ssm.Login.dto.response.LoginResponse;
import com.ssm.Login.entity.User;
import com.ssm.Login.enumeration.TokenType;
import com.ssm.Login.repository.UserRepository;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;


/*
 * ログインサービス
 * author:馬 広超(Rothschilds MA)
 * 作成:2023/05/05
*/

@Service
@RequiredArgsConstructor
public class LoginService {
	
	private final UserRepository userRepository;
	private final UserService userService;
	private final TokenService tokenService;
	private final AuthenticationManager authenticationManager;
	
	private LoginResponse LoginResponseBuilder(String accessToken,String refreshToken) {
		
		Supplier<LoginResponse> responseSupplier = () -> new LoginResponse();
		
		return TemplateBuilder.of(responseSupplier)
				.field("accessToken", accessToken)
				.field("refreshToken", refreshToken)
				.build();
	}

	public LoginResponse add(AddUserRequest addRequest) {
		
		User user = userService.buildUser(addRequest);
		var savedUser = userRepository.save(user);
		String accessToken = tokenService.createToken(user,TokenType.ACCESS);
		String refreshToken = tokenService.createToken(user,TokenType.REFRESH);
		
		userService.saveUserToken(savedUser,accessToken);
		
		return LoginResponseBuilder(accessToken,refreshToken);
	}
	
	public LoginResponse authenticate(LoginRequest loginRequest) {
		
		//認証トークンの生成、LoginRequestから取得したユーザーIDとパスワードが含まれています。
		var namePasswordAuthToken = new UsernamePasswordAuthenticationToken(loginRequest.getUserId(),loginRequest.getPassword());
		
		//認証マネージャに対して認証を要求する、認証プロバイダを呼び出し、ユーザーIDとパスワードのチェックが行う
		authenticationManager.authenticate(namePasswordAuthToken);
		
		var user = userRepository.findByUserId(loginRequest.getUserId()).orElseThrow();
		String accessToken = tokenService.createToken(user,TokenType.ACCESS);
		String refreshToken = tokenService.createToken(user,TokenType.REFRESH);
		userService.revokeAllUserTokens(user);
		userService.saveUserToken(user, accessToken);
		
		return LoginResponseBuilder(accessToken,refreshToken);
	}

	public void refreshToken(HttpServletRequest request, HttpServletResponse response) throws IOException{
		final String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);
		
		if(authHeader == null || !authHeader.startsWith("Bearer ")) return;
		
		final String refreshToken = authHeader.substring(7);

		final String userId = tokenService.getTokenSubject(refreshToken);
		
		if(userId != null) {
			
			User user = userRepository.findByUserId(userId).orElseThrow();
			
			if(tokenService.isTokenValid(refreshToken, user)) {
				
				String accessToken = tokenService.createToken(user, TokenType.ACCESS);
				userService.revokeAllUserTokens(user);
				userService.saveUserToken(user, accessToken);

				new ObjectMapper().writeValue(response.getOutputStream(), LoginResponseBuilder(accessToken,refreshToken));
			}
		}
		
	}
	
	

}
