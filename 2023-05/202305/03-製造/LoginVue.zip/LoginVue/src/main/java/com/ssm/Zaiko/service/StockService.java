package com.ssm.Zaiko.service;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.Zaiko.dao.StockMapper;
import com.ssm.Zaiko.entity.Stock;
import com.ssm.Zaiko.form.SearchForm;

@Service
public class StockService {
	//情報マッパ
	@Autowired
	private StockMapper stockMapper;

	//情報すべて検索

	public List<Stock> findAll() {
		
		return stockMapper.findAll();
		//return sortStockId(stockMapper.findAll());

	}

	public List<Stock> findByCondition(SearchForm searchForm) {
		return stockMapper.findByCondition(searchForm);
		//return sortStockId(stockMapper.findByCondition(searchForm));
	}

	public Stock findMaxIndexOfStock() {
		return stockMapper.findMaxIndexOfStock();
	}
	
	public Stock findByid(String stockId) {
		return stockMapper.findByid(stockId);
	}
	
	
	public void deleteStock(int rowId) {
		stockMapper.deleteStock(rowId);
		
	}

	private List<Stock> sortStockId(List<Stock> list) {
		return list.stream()
				.sorted(Comparator.comparing(Stock::getStockId).reversed())
				.collect(Collectors.toList());

	}
	
	private int getRowid() {
		return stockMapper.getRowid();
	}

}