package com.ssm.Login.enumeration;

public enum AuthorityType {

	USER,
	ADMIN
}
