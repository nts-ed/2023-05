package com.ssm.Zaiko.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssm.Zaiko.entity.MCode;

@Mapper
public interface MCodeMapper {
	List<MCode> iFindUnitName();
}
