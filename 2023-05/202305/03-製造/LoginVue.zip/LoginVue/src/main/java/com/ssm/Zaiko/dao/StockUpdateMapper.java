package com.ssm.Zaiko.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssm.Zaiko.entity.MCode;
import com.ssm.Zaiko.entity.Stock;
import com.ssm.Zaiko.form.AddForm;
import com.ssm.Zaiko.form.UpdateForm;

@Mapper
public interface StockUpdateMapper {
	

	// 社員情報全て検索
	List<Stock> findAll();

	void add(AddForm form);

	void update(UpdateForm form);

	List<Stock> iFindByCondition(UpdateForm form);

	List<MCode> iFindDepatmentName();
	
	  Stock findMaxIndexOfStock();
	
	
}
