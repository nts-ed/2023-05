package com.ssm.Login.exception;

/*
 * 業務例外処理クラス
 * author:馬 広超(Rothschilds MA)
 * 作成:2023/05/05
*/

public class BusinessException extends Exception{

	public BusinessException(String message) {
		super(message);
	}

}
