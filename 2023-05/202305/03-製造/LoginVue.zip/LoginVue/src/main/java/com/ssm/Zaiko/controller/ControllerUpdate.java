package com.ssm.Zaiko.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ssm.Zaiko.entity.Stock;
import com.ssm.Zaiko.form.AddForm;
import com.ssm.Zaiko.form.UpdateForm;
import com.ssm.Zaiko.service.StockService;
import com.ssm.Zaiko.service.StockUpdateService;

@Controller
@RequestMapping(value = "/api/auth")
public class ControllerUpdate {

    @Autowired
    private StockUpdateService stockUpdateService;
    @Autowired
    private StockService stockService;


  //在庫情報更新
    @GetMapping("/zaiko/{id}/update")
	public String update(@PathVariable String id,Model model) {
		AddForm addForm = new AddForm();
		Stock stock = stockService.findByid(id);
		
		addForm.setStockId(stock.getStockId());
		addForm.setName(stock.getName());
		addForm.setUnitId(stock.getUnitId());
		addForm.setRemarks(stock.getRemarks());

		model.addAttribute("addForm", addForm);

		return "stockUpdate/update";
	}
  //在庫情報更新処理
 
    @RequestMapping(value = "/stock/update2", method = RequestMethod.POST)
    public String updateToTabel(@ModelAttribute UpdateForm updateForm) {
        // 在庫情報の更新
        stockUpdateService.update(updateForm); // 情報更新
        return "redirect:/api/auth/zaiko/view";
    }

    
}
