package com.ssm.Login.builder;


import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

import lombok.RequiredArgsConstructor;

/*
 * テンプレートビルダークラス
 * author:馬広超(RothsChilds MA)
 * 作成:2023/05/09
 * GoF:Builder pattern 
 */

@RequiredArgsConstructor
public class TemplateBuilder<T> {
	
	private final Supplier<T> instantiator;
	private Map<String, Object> fieldMap = new HashMap<>();
	
	public static <T> TemplateBuilder<T> of(Supplier<T> instantiator) {
        return new TemplateBuilder<>(instantiator);
    }
	
	public <V> TemplateBuilder<T> field(String name, V value) {
		fieldMap.put(name, value);
        return this;
    }
	
	public T build() {
        T object = instantiator.get();
        fieldMap.forEach((name, value) -> {
        	setField(object, name, value);
        });
        fieldMap.clear();
        return object;
    }
	
	private <V> void setField(T object, String name, V value) {
        try {
            var field = object.getClass().getDeclaredField(name);
            field.setAccessible(true);
            field.set(object, value);
        } catch (Exception e) {
            throw new RuntimeException("フィールドの設定失敗しました。: " + name, e);
        }
    }

}
