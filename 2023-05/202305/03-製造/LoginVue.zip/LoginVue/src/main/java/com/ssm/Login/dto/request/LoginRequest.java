package com.ssm.Login.dto.request;

import java.io.Serializable;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*
 * DTO:ログインリクエストデータ
 * author:馬 広超(Rothschilds MA)
 * 作成:2023/05/05
*/

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginRequest implements Serializable{

	//@JsonProperty("user_id")
	@NotBlank(message = "IDを入力してください。")
	@Size(max = 11, message = "※11文字以内で入力してください")
	private String userId;
	
	@NotBlank(message = "パスワードを入力してください。")
	private String password;
	
}
