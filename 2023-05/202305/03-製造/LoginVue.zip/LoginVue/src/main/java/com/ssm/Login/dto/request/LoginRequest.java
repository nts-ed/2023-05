package com.ssm.Login.dto.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*
 * DTO:ログインリクエストデータ
 * author:馬 広超(Rothschilds MA)
 * 作成:2023/05/05
*/

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LoginRequest implements Serializable{

	@JsonProperty("user_id")
	@NotNull(message = "userId shouldn't be null")
	private String userId;
	
	private String password;
	
}
