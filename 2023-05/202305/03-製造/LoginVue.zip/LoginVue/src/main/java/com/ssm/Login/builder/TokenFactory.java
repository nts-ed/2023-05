package com.ssm.Login.builder;

import java.security.Key;
import java.util.Date;
import java.util.Map;

import org.springframework.security.core.userdetails.UserDetails;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;


/*
 * トークン工場、トークン実体生成のオブジェクト
 * author:馬 広超(Rothschilds MA)
 * 作成:2023/05/05
*/

public class TokenFactory {
	
	private final String token;

	private TokenFactory(String token) {
		this.token = token;
	}
	
	//トークン生成 factory method ==> 引数（ユーザーID,有効時間,秘密鍵）
	public static TokenFactory of(Map<String, Object> extraClaims,UserDetails userDetails,long expiration, Key key) {

		//JSON WEB TOKEN ビルダー処理
		var token = Jwts.builder()
		             .setClaims(extraClaims)
		             .setSubject(userDetails.getUsername())
		             .setIssuedAt(new Date(System.currentTimeMillis()))
		             .setExpiration(new Date(System.currentTimeMillis() + expiration))
		             .signWith(key, SignatureAlgorithm.HS256)
		             .compact();
		
		return new TokenFactory(token);
	}
	
	public String getToken() {
		return this.token;
	}

}
