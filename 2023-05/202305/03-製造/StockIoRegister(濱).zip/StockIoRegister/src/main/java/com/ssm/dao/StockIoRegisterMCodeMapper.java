package com.ssm.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssm.entity.StockIoRegisterMCode;

@Mapper
public class StockIoRegisterMCodeMapper {

	public List<StockIoRegisterMCode> iFindStockId() {
		return null;
	}

}
