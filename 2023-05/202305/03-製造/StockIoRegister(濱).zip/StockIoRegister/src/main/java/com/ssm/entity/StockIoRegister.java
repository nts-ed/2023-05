package com.ssm.entity;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

@Data
public class StockIoRegister implements Serializable {

	//自動採番ID
	private int id;

	//在庫商品ID
	private String stockId;

	//在庫商品名称
	private String name;

	//在庫数量
	private int stockNum;

	//入出庫タイプ
	private String ioTypeId;

	//入手庫数量
	private int ioNum;

	//所属ID
	private String remarks;

	//削除フラグ
	private int delFlg;

	//作成日時
	private Date createDate;

	//作成者id
	private int createUser;

	//更新日時
	private Date updataDate;

	//更新者id
	private String updataUser;

	private boolean checked;

}
