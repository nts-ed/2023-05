package com.ssm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ssm.entity.StockIoRegister;
import com.ssm.entity.StockIoRegisterMCode;
import com.ssm.form.StockIoRegisterAddForm;
import com.ssm.service.StockIoRegisterMCodeService;
import com.ssm.service.StockIoRegisterService;

@Controller
public class StockIoRegisterMainController {
	@Autowired
	private StockIoRegisterMCodeService stockIoRegisterMCodeService;
	@Autowired
	private StockIoRegisterService stockIoRegisterService;

	private List<StockIoRegisterMCode> departmentStockIoRegisterList;

	//入出庫情報登録画面
	@GetMapping("/stockIoRegister/add")
	public String stockIoRegisterAddView(@PathVariable String stockId, Model model) {

		StockIoRegister stockIoRegister = stockIoRegisterService.linkId(stockId);
		StockIoRegisterAddForm stockIoRegisterAddForm = new StockIoRegisterAddForm();

		stockIoRegisterAddForm.setStockId(stockIoRegister.getStockId());
		stockIoRegisterAddForm.setName(stockIoRegister.getName());
		stockIoRegisterAddForm.setStockNum(stockIoRegister.getStockNum());
		stockIoRegisterAddForm.setIoTypeId(stockIoRegister.getIoTypeId());
		stockIoRegisterAddForm.setIoNum(stockIoRegister.getIoNum());
		stockIoRegisterAddForm.setRemarks(stockIoRegister.getRemarks());
		model.addAttribute("stockIoRegisterAddForm", stockIoRegisterAddForm);
		return "/stockIoRegister";
	}

	//入出庫情報登録処理
	@RequestMapping(value = "/stockIo/insert", method = RequestMethod.POST)
	public String stockIoRegisterAddToTable(@Validated StockIoRegisterAddForm stockIoRegisterAddForm,
			BindingResult result, Model model) {

		if (result.hasErrors()) {
			return "stockIoRegister";
		}
		stockIoRegisterService.add(stockIoRegisterAddForm);

		return "redirect:/StockIoRegister/view";
	}

}
