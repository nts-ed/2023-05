package com.ssm.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ssm.entity.StockIoRegister;
import com.ssm.entity.StockIoRegisterMCode;
import com.ssm.form.StockIoRegisterAddForm;

@Mapper
public interface StockIoRegisterMapper {

	//入出庫情報全て検索
	List<StockIoRegister> findAll();

	StockIoRegister linkId(String stockId);

	void stockIoRegisterAdd(StockIoRegisterAddForm form);

	List<StockIoRegister> iFindByCondition(StockIoRegisterAddForm form);

	//削除フラグ用
	void deleteStocks(int stockid);

	StockIoRegister iFindMaxIdOfStockIoRegister();

	List<StockIoRegisterMCode> iFindStockId();
}
