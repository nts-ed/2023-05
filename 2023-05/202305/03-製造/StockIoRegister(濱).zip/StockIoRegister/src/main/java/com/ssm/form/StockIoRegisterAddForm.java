package com.ssm.form;

import java.io.Serializable;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class StockIoRegisterAddForm implements Serializable {

	//在庫商品ID
	private String stockId;

	//在庫商品名称
	private String name;

	//在庫数量
	private int stockNum;

	//入出庫タイプ
	@NotBlank(message = "※入出庫タイプを選択してください。")
	private String ioTypeId;

	//入出庫数量
	@Min(message = "※入出庫数量を入力してください。", value = 0)
	@Max(message = "※入出庫数量を入力してください。", value = 999999)
	private int ioNum;

	//備考
	private String remarks;

	private String updateDate;

	private String updateUser;

	private String createUser;

}
