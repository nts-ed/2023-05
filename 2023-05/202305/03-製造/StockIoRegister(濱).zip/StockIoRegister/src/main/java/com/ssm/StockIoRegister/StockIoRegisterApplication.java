package com.ssm.StockIoRegister;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockIoRegisterApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockIoRegisterApplication.class, args);
	}

}
