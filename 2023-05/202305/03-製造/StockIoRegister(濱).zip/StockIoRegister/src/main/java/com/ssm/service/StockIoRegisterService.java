package com.ssm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.dao.StockIoRegisterMapper;
import com.ssm.entity.StockIoRegister;
import com.ssm.form.StockIoRegisterAddForm;

@Service
public class StockIoRegisterService {

	//入出庫情報マッパ
	@Autowired
	private StockIoRegisterMapper stockIoRegisterMapper;

	//入出庫情報すべて検索

	public List<StockIoRegister> findAll() {
		return stockIoRegisterMapper.findAll();

	}

	public StockIoRegister linkId(String stockId) {
		return stockIoRegisterMapper.linkId(stockId);
	}

	//入出庫情報登録
	public class DuplicateStockIdException extends Exception {
		public DuplicateStockIdException(String stockIoRegistermessage) {
			super(stockIoRegistermessage);
		}
	}

	public void add(StockIoRegisterAddForm form) {

		// データベースに新しい入出庫情報を登録する
		stockIoRegisterMapper.stockIoRegisterAdd(form);
	}

	//削除フラグ
	public void deleteStock(int id, String loginEmployee) {
		stockIoRegisterMapper.deleteStocks(id);
	}

	public List<StockIoRegister> findByCondition(StockIoRegisterAddForm form) {
		return stockIoRegisterMapper.iFindByCondition(form);

	}

	public StockIoRegister findMaxIdOfStockIoRegister() {
		return stockIoRegisterMapper.iFindMaxIdOfStockIoRegister();
	}

}
