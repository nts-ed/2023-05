package com.ssm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.entity.StockIoRegisterMCode;

@Service
public class StockIoRegisterMCodeService {
	@Autowired
	private StockIoRegisterMCodeService stockIoRegisterMCodeMapper;

	public List<StockIoRegisterMCode> iFindStocId() {
		return stockIoRegisterMCodeMapper.iFindStocId();
	}
}
