package com.ssm.form;

import lombok.Data;

@Data
public class StockIoRegisterMCodeForm {
	private String codeId;
	private String codeName;
}